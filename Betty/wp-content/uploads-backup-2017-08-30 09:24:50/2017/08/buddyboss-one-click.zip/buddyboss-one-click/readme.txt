=== BuddyBoss One Click Installer ===
Contributors: buddyboss
Requires at least: 3.8
Tested up to: 4.7.1
Stable tag: 1.0.5

== Description ==

Quickly Setup BuddyBoss Demos on your server using One Click Installer.

== Installation ==

1. Visit 'Plugins > Add New'
2. Click 'Upload Plugin'
3. Upload the file 'buddyboss-one-click.zip'
4. Activate BuddyBoss One Click from your Plugins page

= Configuration =

1. Back up your website
2. Go to BuddyBoss > BuddyBoss One Click
3. Click to Download the demo you want to clone
4. Begin installation

== Changelog ==

= 1.0.5 =
* Fix - support for PHP 5.5 and mysql 5.5
* Added Server information tab

= 1.0.4 =
* HTTPS secure link for BuddyBoss.com resources

= 1.0.3 =
* Admin URL for Installer changed

= 1.0.2 =
* Allow large download files to import on more server types

= 1.0.1 =
* Small Fix

= 1.0.0 =
* Initial Release
